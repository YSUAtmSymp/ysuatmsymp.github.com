Ar7 = rand(5);
Ar7(3) = NaN;